package hashcode2017;

public class Request {
	
	public int id, vidId, endId, nr;
	
	Request(int _id, int _vidId, int _endId, int _n) {
		id = _id;
		vidId = _vidId;
		endId = _endId;
		nr = _n;
	}
}
