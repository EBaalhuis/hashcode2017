package hashcode2017;

public class Video {
	
	public int id, size;
	
	Video(int _id, int _s) {
		id = _id;
		size = _s;
	}
	
}
