package hashcode2017;

public class test {
public static void main(String[] args) {
	System.out.println(Double.compare(0, 1));
}
}
